package com.ob.dao;

public interface IQueryMapper {
	

}
